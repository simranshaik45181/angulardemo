import { Component, OnInit } from '@angular/core';
import { MyServiceService, Products } from '../my-service.service';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit {
service:MyServiceService;
product:Products;
createdFlag=false;
  constructor(service:MyServiceService) {
    this.service=service;
   }

  ngOnInit() {
   
  }

  add(data:any){
    this.product=new Products(data.pid,data.pname,data.pprice,data.pcategory);
    this.service.add(this.product);
    alert("Added Succesfully!!!");
    this.createdFlag=true;
   }
}




  